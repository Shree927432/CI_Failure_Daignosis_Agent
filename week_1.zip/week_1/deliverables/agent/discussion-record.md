# Discussion Record

_TODO: log design discussions and decisions._
