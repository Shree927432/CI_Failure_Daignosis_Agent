# Probability & Decision Record

_TODO: document probabilistic judgments, confidence levels, and rationale._
